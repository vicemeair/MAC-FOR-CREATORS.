# MAC FOR CREATORS

Site statique prêt pour GitHub Pages.

## Mise en ligne
1. Crée un dépôt GitHub public (ex. `mac-for-creators`).
2. Ajoute `index.html` à la racine.
3. Dans Settings > Pages, active le déploiement depuis `main` / `/ (root)`.

## Paiements — à faire avec le représentant légal
- Ne jamais publier une clé API secrète dans le code du site.
- Créer un lien de paiement hébergé Stripe Checkout / Payment Link, avec Apple Pay activé si disponible et configuré sur le compte.
- Créer le lien de paiement PayPal approprié au nom du titulaire adulte.
- Remplacer les deux valeurs `AJOUTER_ICI...` dans le script en bas de `index.html`.
- Tester les liens avant de partager le site.

La jauge est volontairement manuelle : ne pas afficher de faux montants. Modifier le texte de progression seulement après avoir vérifié les contributions.
